import { ctaHighlights } from '../data/siteContent'

export function CTASection() {
  return (
    <section className="relative isolate overflow-hidden bg-white py-24">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_center,_rgba(14,165,233,0.1),_transparent_70%)]" />
      <div className="mx-auto flex w-full max-w-5xl flex-col items-center gap-12 px-4 text-center sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-slate-900 sm:text-4xl">
          Prêt à renforcer votre posture cyber ?
        </h2>
        <p className="max-w-2xl text-base leading-7 text-slate-600">
          Rejoignez les entreprises qui font confiance à Innovatech Consulting pour piloter leur transformation numérique en toute sécurité. Nos experts vous accompagnent à chaque étape.
        </p>
        <div className="grid w-full gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {ctaHighlights.map(({ icon, title, description }) => (
            <div key={title} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="text-3xl">{icon}</div>
              <h3 className="mt-4 text-lg font-semibold text-slate-900">{title}</h3>
              <p className="mt-2 text-sm text-slate-600">{description}</p>
            </div>
          ))}
        </div>
        <div className="flex flex-wrap items-center justify-center gap-4">
          <a
            href="/contact"
            className="inline-flex items-center justify-center rounded-full bg-slate-900 px-7 py-3 text-sm font-semibold text-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg"
          >
            Demander un audit
          </a>
          <a
            href="mailto:contact@innovatech-consulting.com"
            className="inline-flex items-center justify-center rounded-full border border-slate-900 px-7 py-3 text-sm font-semibold text-slate-900 transition hover:bg-slate-900 hover:text-white"
          >
            Écrire à un expert
          </a>
        </div>
      </div>
    </section>
  )
}
