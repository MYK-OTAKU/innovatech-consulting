import { coreValues, storyNarrative } from '../data/siteContent'

export function StorySection() {
  return (
    <section
      id="notre-histoire"
      className="relative overflow-hidden bg-slate-50 py-24"
    >
      <div
        aria-hidden
        className="absolute left-10 top-10 h-24 w-24 rounded-full bg-primary-500/10 blur-3xl"
      />
      <div
        aria-hidden
        className="absolute bottom-16 right-8 h-32 w-32 rounded-full bg-emerald-400/10 blur-3xl"
      />
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-16 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-500">
              Notre histoire
            </p>
            <h2 className="mt-4 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
              Votre phare dans la digitalisation sécurisée
            </h2>
            <div className="mt-8 space-y-5 text-base leading-7 text-slate-600">
              {storyNarrative.map((paragraph) => (
                <p key={paragraph}>{paragraph}</p>
              ))}
            </div>

            <div className="mt-12 grid gap-6 sm:grid-cols-2">
              {coreValues.map(({ title, description }) => (
                <div
                  key={title}
                  className="group relative overflow-hidden rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-primary-500/60 hover:shadow-xl"
                >
                  <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-primary-500 via-slate-900 to-emerald-400 opacity-0 transition group-hover:opacity-100" />
                  <h3 className="text-lg font-semibold text-slate-900">{title}</h3>
                  <p className="mt-3 text-sm text-slate-600">{description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative flex flex-col justify-center">
            <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xl">
              <img
                src="/Images/programming-background.jpg"
                alt="Experts Innovatech en mission de cybersécurité"
                className="h-72 w-full object-cover"
                loading="lazy"
              />
              <div className="space-y-6 p-8">
                <div className="flex items-center gap-3">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-primary-500/10 text-2xl text-primary-600">
                    🧭
                  </span>
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-500">
                      Notre mission
                    </p>
                    <p className="text-sm text-slate-500">
                      Être l’allié stratégique des organisations ambitieuses
                    </p>
                  </div>
                </div>
                <p className="text-sm leading-6 text-slate-600">
                  Nous garantissons la sécurité et la résilience de vos systèmes d’information grâce à un accompagnement personnalisé, depuis le conseil stratégique jusqu’à l’opérationnel.
                </p>
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
                  <p className="text-xs font-semibold uppercase tracking-[0.3em] text-primary-500">
                    Projets innovants
                  </p>
                  <div className="mt-4 flex flex-col gap-3 text-sm text-slate-600">
                    <div className="flex items-center justify-between">
                      <span>DigiCard — cartes de visite digitales</span>
                      <a
                        href="#contact"
                        className="text-xs font-semibold text-primary-500 transition hover:text-primary-400"
                      >
                        Explorer
                      </a>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Cyber MSSP — supervision proactive</span>
                      <a
                        href="#services"
                        className="text-xs font-semibold text-primary-500 transition hover:text-primary-400"
                      >
                        En savoir plus
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
