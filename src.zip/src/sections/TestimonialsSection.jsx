import { testimonials } from '../data/siteContent'

export function TestimonialsSection({ withHero = false }) {
  return (
    <section className={withHero ? 'bg-slate-900 py-24 text-white' : 'bg-slate-50 py-24'}>
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className={withHero ? 'max-w-2xl text-center mx-auto' : 'grid gap-8 lg:grid-cols-[1fr_1.1fr] lg:items-center'}>
          <div>
            <p className={withHero ? 'text-sm font-semibold uppercase tracking-[0.3em] text-primary-200' : 'text-sm font-semibold uppercase tracking-[0.3em] text-primary-500'}>
              Témoignages
            </p>
            <h2 className={withHero ? 'mt-4 text-3xl font-bold sm:text-4xl' : 'mt-4 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl'}>
              Ce que nos clients disent de nous
            </h2>
            <p className={withHero ? 'mt-5 text-base text-slate-200' : 'mt-5 text-base text-slate-600'}>
              Nous créons des relations de confiance durables en combinant expertise, transparence et support dédié. Découvrez quelques retours clients.
            </p>
          </div>
          {!withHero && (
            <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-lg">
              <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-500">
                Notre valeur ajoutée
              </p>
              <p className="mt-4 text-sm leading-6 text-slate-600">
                « La qualité est au cœur de notre identité. Chaque client mérite le meilleur, et nous nous efforçons d’assurer l’efficacité et la durabilité de chaque solution. »
              </p>
              <div className="mt-6 text-sm text-slate-500">
                <p className="font-semibold text-slate-700">Direction Innovatech Consulting</p>
                <p>Cybersécurité & Innovation</p>
              </div>
            </div>
          )}
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial) => (
            <figure
              key={testimonial.author}
              className={
                withHero
                  ? 'flex h-full flex-col rounded-2xl border border-white/15 bg-white/10 p-6 shadow-xl shadow-black/20 backdrop-blur'
                  : 'flex h-full flex-col rounded-2xl border border-slate-200 bg-white p-6 shadow-sm'
              }
            >
              <p className={withHero ? 'text-sm leading-6 text-slate-100' : 'text-sm leading-6 text-slate-600'}>
                « {testimonial.quote} »
              </p>
              <div className="mt-6 border-t border-current/10 pt-4">
                <figcaption className={withHero ? 'text-sm text-slate-200' : 'text-sm text-slate-500'}>
                  <p className={withHero ? 'font-semibold text-white' : 'font-semibold text-slate-900'}>
                    {testimonial.author}
                  </p>
                  <p>{testimonial.role}</p>
                  <p className="mt-2 text-xs text-amber-500">{'★'.repeat(testimonial.rating)}</p>
                </figcaption>
              </div>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
