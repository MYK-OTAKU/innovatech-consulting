import { services } from '../data/siteContent'

export function ServicesSection() {
  return (
    <section
      id="services"
      className="relative overflow-hidden bg-slate-950 py-24 text-white"
    >
      <div
        aria-hidden
        className="absolute inset-y-0 left-1/2 hidden w-px bg-gradient-to-b from-transparent via-white/20 to-transparent lg:block"
      />
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-200">
            Services gérés & expertise
          </p>
          <h2 className="mt-4 text-3xl font-bold sm:text-4xl">
            Des offres pensées pour votre résilience cyber
          </h2>
          <p className="mt-5 text-base text-slate-300">
            MSSP, SOC, CyberDefense et GRC : nous orchestrons des dispositifs complets et évolutifs pour protéger vos systèmes d’information, de la stratégie à l’opérationnel.
          </p>
        </div>

        <div className="mt-16 grid gap-10 lg:grid-cols-3">
          {services.map((service) => (
            <article
              key={service.title}
              className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-8 shadow-2xl shadow-black/30 backdrop-blur transition hover:-translate-y-1 hover:border-primary-400/60"
            >
              <div className="absolute -top-40 left-1/2 h-64 w-64 -translate-x-1/2 transform rounded-full bg-primary-500/10 blur-3xl transition group-hover:bg-primary-500/20" />
              <div className="relative">
                <span className="text-xs font-semibold uppercase tracking-[0.4em] text-primary-200">
                  {service.category}
                </span>
                <h3 className="mt-4 text-2xl font-semibold text-white">
                  {service.title}
                </h3>
                <p className="mt-3 text-sm leading-6 text-slate-300">
                  {service.description}
                </p>
              </div>

              <div className="relative mt-6 overflow-hidden rounded-2xl border border-white/10">
                <img
                  src={service.image}
                  alt={service.title}
                  className="h-44 w-full object-cover transition duration-700 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-slate-950/80 via-transparent to-slate-950/20" />
              </div>

              <ul className="relative mt-6 flex flex-1 flex-col gap-3 text-sm text-slate-200">
                {service.points.map((point) => (
                  <li key={point} className="flex items-start gap-3">
                    <span className="mt-1 inline-flex h-5 w-5 flex-none items-center justify-center rounded-full bg-primary-500/20 text-primary-200">
                      ✓
                    </span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>

              <a
                href="#contact"
                className="relative mt-8 inline-flex items-center gap-2 text-sm font-semibold text-primary-200 transition hover:text-primary-100"
              >
                Parler à un expert
                <span aria-hidden className="text-base">
                  →
                </span>
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
