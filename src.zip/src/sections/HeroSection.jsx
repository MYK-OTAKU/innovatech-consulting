import { stats } from '../data/siteContent'

const featureBullets = [
  'Piloter votre cybersécurité depuis un cockpit unifié',
  'Activation rapide : audit et plan d’actions livrés en 10 jours',
  'Visibilité temps réel sur les menaces et la conformité',
]

export function HeroSection() {
  return (
    <section
      id="accueil"
      className="relative isolate overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-[#020617] text-white"
    >
      <div className="absolute inset-0">
        <div className="absolute -left-20 top-0 h-64 w-64 rounded-full bg-primary-500/30 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-80 w-80 rounded-full bg-emerald-400/20 blur-[140px]" />
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.04]" />
      </div>

      <div className="mx-auto grid w-full max-w-6xl gap-16 px-4 pb-28 pt-36 sm:px-6 lg:grid-cols-[1.15fr_0.85fr] lg:px-8">
        <div className="relative z-10 flex flex-col gap-10">
          <div className="inline-flex items-center gap-3 self-start rounded-full border border-white/10 bg-white/5 px-5 py-2 text-xs font-semibold uppercase tracking-[0.35em] text-white/80">
            <span className="h-2 w-2 rounded-full bg-emerald-400" />
            Digital Trust Platform
          </div>

          <div className="space-y-8">
            <h1 className="text-4xl font-black leading-tight tracking-tight sm:text-5xl lg:text-[3.5rem] lg:leading-[1.05]">
              Le copilote de votre cybersécurité <span className="text-primary-300">géré de bout en bout</span>
            </h1>
            <p className="max-w-xl text-base leading-7 text-slate-200 sm:text-lg">
              Innovatech Consulting centralise MSSP, SOC, CyberDefense et GRC pour offrir une expérience fluide, mesurable et immédiatement opérationnelle pour vos équipes métiers et RSSI.
            </p>
            <ul className="grid gap-3 text-sm text-slate-300">
              {featureBullets.map((bullet) => (
                <li key={bullet} className="flex items-start gap-3">
                  <span className="mt-1 inline-flex h-6 w-6 flex-none items-center justify-center rounded-full bg-primary-500/20 text-primary-200">
                    ✓
                  </span>
                  <span>{bullet}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <a
              href="#services"
              className="inline-flex items-center justify-center rounded-full bg-white px-8 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-primary-500/30 transition hover:-translate-y-0.5 hover:shadow-2xl"
            >
              Découvrir la plateforme
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-transparent px-8 py-3 text-sm font-semibold text-white transition hover:border-white"
            >
              <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-white/10 text-sm font-semibold">▶</span>
              Planifier une démo
            </a>
          </div>

          <div className="flex flex-wrap gap-4 text-xs font-semibold uppercase tracking-[0.35em] text-white/60">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2">
              ⚡ Audit flash 48h
            </span>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2">
              🔐 SOC hybride certifié
            </span>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2">
              📊 Reporting exécutif live
            </span>
          </div>
        </div>

        <div className="relative z-10 flex flex-col justify-center">
          <div className="relative overflow-hidden rounded-[32px] border border-white/10 bg-white/5 px-8 pb-10 pt-12 shadow-[0_40px_120px_-40px_rgba(30,64,175,0.55)] backdrop-blur-lg">
            <div className="absolute -top-20 right-10 h-40 w-40 rounded-full bg-primary-400/30 blur-3xl" />
            <div className="absolute bottom-0 left-0 h-32 w-32 rounded-full bg-emerald-400/20 blur-3xl" />

            <div className="relative flex flex-col gap-8">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.3em] text-white/60">
                  Passe digital client
                </p>
                <div className="mt-4 rounded-3xl border border-white/10 bg-gradient-to-br from-white/20 via-white/10 to-white/5 p-6 shadow-inner">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-white/80">Security Score</p>
                      <p className="mt-1 text-3xl font-bold text-white">96/100</p>
                    </div>
                    <span className="rounded-full bg-primary-500/20 px-3 py-1 text-xs font-semibold text-primary-200">
                      Live
                    </span>
                  </div>
                  <div className="mt-6 space-y-3 text-xs text-white/70">
                    <div className="flex items-center justify-between">
                      <span>Incidents traités</span>
                      <span className="font-semibold text-white">12</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Actions en cours</span>
                      <span className="font-semibold text-white">3</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Conformité</span>
                      <span className="font-semibold text-white">ISO · PCI-DSS · Swift</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="rounded-3xl border border-white/10 bg-white/5 p-5 text-sm text-white/80">
                <p className="font-semibold text-white">Mission en temps réel</p>
                <p className="mt-2 text-xs text-white/70">SOC Finance · Maroc · SLA 15 min</p>
                <div className="mt-4 grid gap-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs uppercase tracking-[0.25em] text-white/60">Threat hunting</span>
                    <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-emerald-300">
                      Actif
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs uppercase tracking-[0.25em] text-white/60">Runbook Incidents</span>
                    <span className="text-xs text-white">8 procédures</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <dl className="mt-10 grid gap-4 sm:grid-cols-2">
            {stats.map(({ label, value, description }) => (
              <div
                key={label}
                className="rounded-2xl border border-white/10 bg-white/5 p-6 shadow-lg shadow-primary-500/20 backdrop-blur"
              >
                <dt className="text-xs font-semibold uppercase tracking-[0.3em] text-white/60">
                  {label}
                </dt>
                <dd className="mt-2 text-3xl font-bold text-white">{value}</dd>
                <p className="mt-2 text-xs text-white/70">{description}</p>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}
