import { partners } from '../data/siteContent'

export function PartnersSection() {
  return (
    <section className="bg-slate-900 py-20 text-white">
      <div className="mx-auto flex w-full max-w-6xl flex-col items-center gap-10 px-4 text-center sm:px-6 lg:px-8">
        <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-200">
          Ils nous font confiance
        </p>
        <h2 className="text-3xl font-bold sm:text-4xl">
          Des partenaires leaders en cybersécurité et innovation
        </h2>
        <p className="max-w-3xl text-base text-slate-300">
          Nous collaborons avec des acteurs de référence pour mettre en œuvre des solutions robustes, performantes et adaptées à vos exigences de conformité.
        </p>
        <div className="grid w-full gap-6 sm:grid-cols-3">
          {partners.map((partner) => (
            <div
              key={partner.name}
              className="flex h-36 items-center justify-center rounded-2xl border border-white/10 bg-white/5 backdrop-blur transition hover:-translate-y-1"
            >
              <img
                src={partner.logo}
                alt={partner.name}
                className="max-h-16 max-w-[140px] object-contain"
                loading="lazy"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
