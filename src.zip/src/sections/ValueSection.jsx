import { differentiators } from '../data/siteContent'

export function ValueSection() {
  return (
    <section
      id="valeur"
      className="relative overflow-hidden bg-white py-24"
    >
      <div
        aria-hidden
        className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(59,130,246,0.12),_transparent_60%)]"
      />
      <div className="relative mx-auto grid w-full max-w-6xl gap-16 px-4 sm:px-6 lg:grid-cols-[1.1fr_1fr] lg:px-8">
        <div className="space-y-8">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-500">
              Proposition de valeur unique
            </p>
            <h2 className="mt-4 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
              Pourquoi les organisations choisissent Innovatech Consulting
            </h2>
            <p className="mt-6 text-base leading-7 text-slate-600">
              Innovation, excellence opérationnelle et expertise sectorielle : nous co-construisons des solutions cyber adaptées à vos priorités business, tout en assurant une conformité irréprochable.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            {differentiators.map(({ title, description }) => (
              <div
                key={title}
                className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-primary-500/60 hover:shadow-lg"
              >
                <span className="text-xl">✨</span>
                <h3 className="mt-4 text-lg font-semibold text-slate-900">{title}</h3>
                <p className="mt-3 text-sm text-slate-600">{description}</p>
              </div>
            ))}
          </div>

          <div className="rounded-3xl border border-slate-200 bg-slate-50/70 p-8">
            <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-500">
              Témoignage client
            </p>
            <blockquote className="mt-4 text-base leading-7 text-slate-600">
              « Grâce à Innovatech Consulting, nous avons mis en place notre Security Operation Center avec succès. Leur équipe, disponible à chaque étape, a fait la différence. »
            </blockquote>
            <div className="mt-6 text-sm text-slate-500">
              <p className="font-semibold text-slate-700">Adama Coulibaly</p>
              <p>RSSI — Confidentiel</p>
              <p className="mt-2 text-xs text-amber-500">★★★★★</p>
            </div>
          </div>
        </div>

        <div className="relative">
          <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-to-br from-primary-500/10 to-transparent blur-2xl" />
          <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl shadow-primary-500/10">
            <img
              src="/Images/code-reflection-digital.webp"
              alt="Visualisation de cybersécurité Innovatech"
              className="h-72 w-full object-cover"
              loading="lazy"
            />
            <div className="space-y-6 p-8">
              <div className="flex items-start gap-4">
                <div className="grid h-12 w-12 place-items-center rounded-2xl bg-primary-500/10 text-2xl text-primary-600">
                  🛡️
                </div>
                <div>
                  <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-500">
                    Notre approche
                  </p>
                  <p className="mt-2 text-sm leading-6 text-slate-600">
                    Une gouvernance claire, des processus alignés et des équipes engagées pour anticiper chaque menace.
                  </p>
                </div>
              </div>
              <div className="grid gap-4 text-sm text-slate-600">
                <div className="flex items-center gap-3">
                  <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-700">
                    01
                  </span>
                  <p>Diagnostic stratégique & cartographie des risques</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-700">
                    02
                  </span>
                  <p>Déploiement de solutions MSSP, SOC & GRC sur mesure</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-700">
                    03
                  </span>
                  <p>Amélioration continue & reporting piloté par la donnée</p>
                </div>
              </div>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 text-sm font-semibold text-primary-500 transition hover:text-primary-400"
              >
                Co-construire votre feuille de route
                <span aria-hidden className="text-base">
                  →
                </span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
