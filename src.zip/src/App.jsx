import RootLayout from './layouts/RootLayout'

export default function App() {
  return <RootLayout />
}
