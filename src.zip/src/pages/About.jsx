import { StorySection } from '../sections/StorySection'
import { MissionSection } from '../sections/MissionSection'
import { TestimonialsSection } from '../sections/TestimonialsSection'

export function About() {
  return (
    <div className="bg-slate-50">
      <div className="relative overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 text-white">
        <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 px-4 py-24 sm:px-6 lg:px-8">
          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-200">
            À propos
          </p>
          <h1 className="text-4xl font-bold sm:text-5xl">
            Notre mission : sécuriser et propulser votre transformation numérique
          </h1>
          <p className="max-w-3xl text-base text-slate-200">
            Fondée sur l’expertise et le dévouement, Innovatech Consulting vous accompagne dans la maîtrise des risques cyber tout en développant des expériences digitales résilientes.
          </p>
        </div>
      </div>
      <StorySection />
      <MissionSection />
      <TestimonialsSection />
    </div>
  )
}

export default About
