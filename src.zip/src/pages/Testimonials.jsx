import { TestimonialsSection } from '../sections/TestimonialsSection'

const stats = [
  {
    value: '150+',
    label: 'Clients protégés',
  },
  {
    value: '63%',
    label: 'Réduction moyenne du temps de réponse',
  },
  {
    value: '24/7',
    label: 'Support et supervision',
  },
]

export function Testimonials() {
  return (
    <div className="bg-slate-50">
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-blue-900 py-24 text-white">
        <div className="mx-auto flex w-full max-w-6xl flex-col gap-8 px-4 sm:px-6 lg:flex-row lg:items-center lg:gap-16 lg:px-8">
          <div className="flex-1 space-y-6">
            <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary-200">
              Témoignages
            </p>
            <h1 className="text-4xl font-bold sm:text-5xl">
              Ils nous font confiance pour sécuriser leurs opérations critiques
            </h1>
            <p className="max-w-2xl text-base text-slate-200">
              Les retours de nos clients reflètent notre engagement envers l’excellence, la transparence et la valeur délivrée. Découvrez leurs expériences.
            </p>
          </div>
          <dl className="grid flex-1 grid-cols-1 gap-4 sm:grid-cols-3">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="rounded-2xl border border-white/10 bg-white/5 p-6 text-center shadow-lg shadow-black/20"
              >
                <dt className="text-xs font-semibold uppercase tracking-[0.2em] text-white/70">
                  {stat.label}
                </dt>
                <dd className="mt-3 text-3xl font-bold text-white">{stat.value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>

      <TestimonialsSection withHero />

      <section className="bg-white py-24">
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 sm:px-6 lg:grid-cols-[1.1fr_1fr] lg:px-8">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
              Une approche collaborative et orientée résultats
            </h2>
            <p className="mt-6 text-base text-slate-600">
              Nous travaillons main dans la main avec vos équipes pour comprendre vos contraintes, prioriser vos enjeux et livrer des dispositifs sur mesure qui augmentent votre résilience cyber.
            </p>
          </div>
          <div className="rounded-3xl border border-slate-200 bg-slate-50/70 p-8 text-sm text-slate-600">
            <p className="font-semibold text-slate-900">“Plus qu’un prestataire, un partenaire de confiance.”</p>
            <p className="mt-3">
              Notre équipe est disponible à chaque étape pour garantir un suivi régulier, un reporting clair et des recommandations actionnables.
            </p>
            <a
              href="/contact"
              className="mt-6 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.3em] text-primary-500 transition hover:text-primary-400"
            >
              Contactez-nous
              <span aria-hidden>→</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Testimonials
