import { ContactHero } from '../sections/ContactHero'
import { contactInfo } from '../data/siteContent'

const contactChannels = [
  {
    title: 'Support MSSP & SOC',
    description: 'Monitoring 24/7, gestion d’incidents, escalade prioritaire.',
    icon: '🛡️',
    action: 'support@innovatech-consulting.com',
  },
  {
    title: 'Conseil & projets GRC',
    description: 'SMSI, PCA/PRA, schémas directeurs, conformité ISO & PCI-DSS.',
    icon: '📊',
    action: 'grc@innovatech-consulting.com',
  },
  {
    title: 'Formations & sensibilisation',
    description: 'Programmes sur mesure pour vos collaborateurs et dirigeants.',
    icon: '🎓',
    action: 'academy@innovatech-consulting.com',
  },
]

const faqs = [
  {
    question: 'Quel est votre délai de réponse moyen ?',
    answer:
      'Nous répondons à toute sollicitation sous 2 heures ouvrées. Pour les incidents critiques, un canal de réponse prioritaire est activé instantanément.',
  },
  {
    question: 'Proposez-vous un audit cyber gratuit ?',
    answer:
      'Oui, un pré-audit de maturité cyber est offert pour qualifier vos enjeux et cartographier vos priorités à court terme.',
  },
  {
    question: 'Peut-on externaliser notre SOC chez vous ?',
    answer:
      'Nous opérons un CyberSOC basé au Maroc, disponible 24/7, avec threat hunting, réponse aux incidents et reporting exécutif.',
  },
  {
    question: 'Travaillez-vous avec des organisations internationales ?',
    answer:
      'Nous accompagnons des clients en Europe et en Afrique, avec des dispositifs conformes aux exigences réglementaires locales.',
  },
]

export function Contact() {
  return (
    <div className="bg-slate-50">
      <ContactHero />

      <section className="-mt-16 pb-24">
        <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
            <div className="rounded-3xl border border-slate-200 bg-white p-10 shadow-xl">
              <h2 className="text-2xl font-semibold text-slate-900">
                Discutons de vos enjeux
              </h2>
              <p className="mt-3 text-sm text-slate-600">
                Notre équipe d’experts est disponible pour concevoir avec vous une trajectoire cyber réaliste, priorisée et mesurable.
              </p>
              <div className="mt-8 grid gap-5 sm:grid-cols-3">
                {contactChannels.map((channel) => (
                  <div key={channel.title} className="rounded-2xl border border-slate-200 bg-slate-50/70 p-5">
                    <span className="text-2xl">{channel.icon}</span>
                    <h3 className="mt-3 text-base font-semibold text-slate-900">
                      {channel.title}
                    </h3>
                    <p className="mt-2 text-sm text-slate-600">{channel.description}</p>
                    <p className="mt-4 text-xs font-semibold uppercase tracking-[0.3em] text-primary-500">
                      {channel.action}
                    </p>
                  </div>
                ))}
              </div>
              <div className="mt-8 grid gap-4 text-sm text-slate-600 sm:grid-cols-2">
                <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-5">
                  <p className="text-xs font-semibold uppercase tracking-[0.3em] text-primary-500">
                    Bureau Casablanca
                  </p>
                  <p className="mt-3 text-sm text-slate-600">{contactInfo.address}</p>
                  <a
                    href="https://maps.google.com"
                    target="_blank"
                    rel="noreferrer"
                    className="mt-4 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.3em] text-primary-500 transition hover:text-primary-400"
                  >
                    Voir sur Google Maps
                    <span aria-hidden>↗</span>
                  </a>
                </div>
                <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-5">
                  <p className="text-xs font-semibold uppercase tracking-[0.3em] text-primary-500">
                    Horaires & urgences
                  </p>
                  <p className="mt-3 text-sm text-slate-600">
                    {`Standard : ${contactInfo.hours}`}
                    <br />
                    SOC & incidents : 24/7
                  </p>
                  <p className="mt-4 text-xs font-semibold uppercase tracking-[0.3em] text-primary-500">
                    {contactInfo.phone} · {contactInfo.phoneAlt}
                  </p>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-slate-200 bg-white p-10 shadow-xl">
              <h2 className="text-2xl font-semibold text-slate-900">Questions fréquentes</h2>
              <p className="mt-2 text-sm text-slate-600">
                Anticipez vos prochains échanges avec nos équipes en consultant cette base de questions/réponses.
              </p>
              <div className="mt-8 space-y-4">
                {faqs.map((faq) => (
                  <details
                    key={faq.question}
                    className="group rounded-2xl border border-slate-200 bg-slate-50/70 p-5"
                  >
                    <summary className="flex cursor-pointer items-center justify-between text-left text-sm font-semibold text-slate-900">
                      {faq.question}
                      <span className="ml-3 text-lg text-primary-500 transition group-open:rotate-45">+</span>
                    </summary>
                    <p className="mt-3 text-sm text-slate-600">{faq.answer}</p>
                  </details>
                ))}
              </div>
              <div className="mt-8 rounded-2xl border border-primary-500/30 bg-primary-500/10 p-6 text-sm text-slate-700">
                <p className="font-semibold text-slate-900">Besoin d’une réponse immédiate ?</p>
                <p className="mt-2">
                  Contactez notre centre de réponse aux incidents 24/7 :
                  <br />
                  <span className="font-semibold">incident@innovatech-consulting.com</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Contact
